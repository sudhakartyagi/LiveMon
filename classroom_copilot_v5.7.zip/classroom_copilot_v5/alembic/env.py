import os
from alembic import context
from sqlalchemy import engine_from_config, pool
from app.models import Base

config = context.config
target_metadata = Base.metadata

# DATABASE_URL env var wins over alembic.ini so docker/CI/sandbox deployments
# can point migrations at the right database without editing files.
_db_url = os.getenv("DATABASE_URL")
if _db_url:
    config.set_main_option("sqlalchemy.url", _db_url)

def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()

run_migrations_online()

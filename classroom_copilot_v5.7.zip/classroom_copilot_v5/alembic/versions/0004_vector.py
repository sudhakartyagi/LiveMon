"""Add pgvector for curriculum RAG"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from pgvector.sqlalchemy import Vector

revision = "0004"
down_revision = "0003"

def upgrade():
    # Enable pgvector extension
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    
    op.create_table(
        "curriculum_docs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("school_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("schools.id"), nullable=False),
        sa.Column("content", sa.String(2000), nullable=False),
        sa.Column("embedding", Vector(1536), nullable=True),
    )
    
    op.execute("ALTER TABLE curriculum_docs ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE curriculum_docs FORCE ROW LEVEL SECURITY")
    op.execute("CREATE POLICY tenant_isolation ON curriculum_docs USING (school_id = current_setting('app.current_tenant_id', true)::uuid) WITH CHECK (school_id = current_setting('app.current_tenant_id', true)::uuid)")
    op.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON curriculum_docs TO app_user")

def downgrade():
    op.execute("DROP TABLE IF EXISTS curriculum_docs CASCADE")

"""v5.7 permission-first action flow.

Adds to agent_actions:
  - proposed_text : what the agent wants to say/show (spoken only after
                    the teacher allows it)
  - meta          : structured detection info (statement, verdict,
                    asr_confidence, detector)
  - approved_by   : teacher/principal who decided
  - decided_at    : when it was decided

No new tables; RLS policy on agent_actions already exists (0001).
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0005"
down_revision = "0004"


def upgrade():
    op.add_column("agent_actions", sa.Column("proposed_text", sa.String(500), nullable=True))
    op.add_column("agent_actions", sa.Column("meta", postgresql.JSONB, nullable=True))
    op.add_column("agent_actions", sa.Column("approved_by", postgresql.UUID(as_uuid=True), nullable=True))
    op.add_column("agent_actions", sa.Column("decided_at", sa.DateTime, nullable=True))


def downgrade():
    op.drop_column("agent_actions", "decided_at")
    op.drop_column("agent_actions", "approved_by")
    op.drop_column("agent_actions", "meta")
    op.drop_column("agent_actions", "proposed_text")

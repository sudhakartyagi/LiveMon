import uuid
from sqlalchemy import text
from app.db import tenant_session

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_audio_ingest_noise_trigger(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})
    
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(two_schools["class_a"]), 
        "lesson_id": str(lesson_id), # Pass valid lesson_id
        "transcript": "Let's move to page 42", 
        "speaker": "teacher", 
        "noise_db": 80
    })
    assert r.status_code == 200
    assert r.json()["status"] == "action_triggered"
    assert r.json()["tier"] == 2

def test_kill_switch(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})

    class_id = two_schools["class_a"]
    r = client.post(f"/agent/pause/{class_id}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 200
    
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(class_id), 
        "lesson_id": str(lesson_id),
        "transcript": "Talking", 
        "speaker": "teacher", 
        "noise_db": 90
    })
    assert r.json()["status"] == "ignored"

"""MathGuard — deterministic spoken-math verification (v5.7 core fix).

The cases here mirror real classroom speech from the live pilot, including
the exact utterances that failed before: "2 plus 2 is 3" produced no event,
"2 minus 2 is not equal to 0" produced no event, and the garbled
"one half is greater than three letters" produced a FALSE event.
"""
from app.mathguard import check


def _status(text):
    v = check(text)
    return None if v is None else v.status


# ---- the money cases (user-reported failures) ----------------------------

def test_two_plus_two_is_three_is_error():
    v = check("2 plus 2 is 3")
    assert v is not None and v.status == "error"
    assert "4" in v.correction
    assert v.kind == "arithmetic_error"

def test_two_minus_two_not_equal_zero_is_error():
    v = check("2 minus 2 is not equal to 0")
    assert v is not None and v.status == "error"
    assert "equal" in v.explanation.lower()
    assert v.correction  # a correction is always attached to errors

def test_garbled_fraction_phrase_is_not_an_event():
    # THE original false positive: must parse to NOTHING
    assert check("So one half is greater than three letters") is None

def test_correct_fraction_comparison_is_not_an_event():
    v = check("one half is greater than one third")
    assert v is not None and v.status == "correct"

def test_half_bigger_than_three_quarters_is_error():
    v = check("1/2 is bigger than 3/4")
    assert v is not None and v.status == "error"
    assert v.topic == "fractions"


# ---- operations -----------------------------------------------------------

def test_into_means_multiply():
    assert _status("2 into 3 is 6") == "correct"
    assert _status("2 into 3 is 5") == "error"

def test_times():
    assert _status("2 times 2 is 4") == "correct"

def test_hinglish_numerals():
    assert _status("do plus do is chaar") == "correct"

def test_word_numbers_up_to_hundred():
    assert _status("twenty five plus seventy five is one hundred") == "correct"
    assert _status("seven into eight is fifty six") == "correct"
    assert _status("seven into eight is fifty four") == "error"

def test_division():
    assert _status("1000 divided by 8 is 125") == "correct"
    assert _status("10 divided by 3 is 3.33") == "correct"  # 2-dp rounding ok

def test_division_by_zero():
    v = check("2 divided by 0 is 0")
    assert v is not None and v.status == "error"
    assert v.kind == "division_by_zero"
    assert "zero" in v.explanation.lower()

def test_unary_minus_result():
    assert _status("10 minus 15 is minus 5") == "correct"

def test_negated_claims():
    assert _status("2 plus 2 is not 5") == "correct"
    assert _status("2 plus 2 is not 4") == "error"
    assert _status("2 minus 2 is equal to 0") == "correct"
    assert _status("two minus three is not minus one") == "error"

def test_sum_product_difference_phrases():
    assert _status("sum of 2 and 3 is 5") == "correct"
    assert _status("product of 3 and 4 is 12") == "correct"
    assert _status("5 subtracted from 9 is 4") == "correct"

def test_and_as_plus():
    assert _status("2 and 2 is 4") == "correct"
    assert _status("2 and 2 is 5") == "error"

def test_fractions_of_numbers():
    assert _status("half of 10 is 5") == "correct"
    assert _status("half of 10 is 4") == "error"
    assert _status("two thirds of 90 is 60") == "correct"
    assert _status("one third of 30 is 10") == "correct"

def test_double_and_by_fractions():
    assert _status("double of 7 is 14") == "correct"
    v = check("3 by 4 is smaller than 1 by 2")
    assert v is not None and v.status == "error"

def test_decimals():
    assert _status("0.5 is greater than 0.05") == "correct"
    assert _status("0.5 is greater than 0.5") == "error"


# ---- MUST NOT produce events ----------------------------------------------

def test_questions_produce_nothing():
    assert check("what is 2 plus 2") is None

def test_page_references_produce_nothing():
    assert check("let's move to page 42") is None
    assert check("open your books to page 24") is None

def test_classroom_chatter_produces_nothing():
    assert check("Are you listening to me or something else") is None
    assert check("I want you to be as perfect as possible") is None
    assert check("Is this happening with the whole team") is None
    assert check("table of two") is None
    assert check("noise is high today") is None

def test_bare_comparison_without_copula_is_not_a_claim():
    # "3 less than 5" usually means "5 minus 3" — never claim it
    assert check("3 less than 5") is None

def test_empty_and_garbage():
    assert check("") is None
    assert check("   ") is None
    assert check("the quick brown fox") is None

import os
import base64
import json

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_school_a_sees_own_student(client, two_schools):
    r = client.get(f"/students/{two_schools['student_a']}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 200
    assert r.json()["pseudonym"] == "stuA"

def test_school_a_cannot_see_school_b_student(client, two_schools):
    r = client.get(f"/students/{two_schools['student_b']}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 404

def test_school_b_cannot_see_school_a_student(client, two_schools):
    r = client.get(f"/students/{two_schools['student_a']}", headers=auth(two_schools["token_b"]))
    assert r.status_code == 404

def test_no_token_rejected(client, two_schools):
    r = client.get(f"/students/{two_schools['student_a']}")
    assert r.status_code == 422

def test_bad_token_rejected(client, two_schools):
    r = client.get(f"/students/{two_schools['student_a']}", headers={"Authorization": "Bearer garbage"})
    assert r.status_code == 401

def test_unsigned_token_rejected(client, two_schools):
    h = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode()).rstrip(b"=").decode()
    p = base64.urlsafe_b64encode(
        json.dumps({"sub": "x", "school_id": str(two_schools["school_b"]), "role": "teacher"}).encode()
    ).rstrip(b"=").decode()
    unsigned = f"{h}.{p}."
    r = client.get(f"/students/{two_schools['student_b']}", headers={"Authorization": f"Bearer {unsigned}"})
    assert r.status_code == 401

def test_forgot_tenant_context_returns_nothing(setup_schema):
    from sqlalchemy import create_engine, text
    eng = create_engine(os.getenv("DATABASE_URL", "postgresql+psycopg://app_user:app_pass@localhost:5432/copilot"))
    with eng.connect() as c:
        rows = c.execute(text("SELECT count(*) FROM students")).scalar()
        assert rows == 0

def test_rls_policies_exist(setup_schema):
    from sqlalchemy import create_engine, text
    eng = create_engine(os.getenv("TEST_SUPER_URL", "postgresql+psycopg://postgres:postgres@localhost:5432/copilot"))
    with eng.connect() as c:
        for t in ["teachers", "principals", "classes", "students", "lessons", "agent_actions"]:
            rls = c.execute(
                text("SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE relname=:t"),
                {"t": t},
            ).one()
            assert rls[0] is True and rls[1] is True, f"{t} missing RLS"
            policy = c.execute(
                text("SELECT count(*) FROM pg_policies WHERE tablename=:t AND policyname='tenant_isolation'"),
                {"t": t},
            ).scalar()
            assert policy == 1, f"{t} missing policy"

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

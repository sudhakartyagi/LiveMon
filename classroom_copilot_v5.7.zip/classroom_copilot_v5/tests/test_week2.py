import uuid
import threading
from sqlalchemy import text
from app.db import tenant_session

def test_policy_engine_routing():
    from app.engine import PolicyEngine
    assert PolicyEngine.route_action("timer", {}, {}) == 2
    assert PolicyEngine.route_action("timer", {}, {"rules": {"timer": 3}}) == 3
    assert PolicyEngine.route_action("timer", {"teacher_absent_minutes": 4}, {}) == 4

def test_concurrent_isolation(two_schools):
    errors = []
    def query_school(school_id, expected_pseudonym):
        try:
            with tenant_session(school_id) as db:
                import time; time.sleep(0.1)
                result = db.execute(text("SELECT pseudonym FROM students")).fetchall()
                assert len(result) == 1
                assert result[0][0] == expected_pseudonym
        except Exception as e:
            errors.append(e)
    threads = []
    for _ in range(10):
        threads.append(threading.Thread(target=query_school, args=(two_schools["school_a"], "stuA")))
        threads.append(threading.Thread(target=query_school, args=(two_schools["school_b"], "stuB")))
    for t in threads: t.start()
    for t in threads: t.join()
    assert len(errors) == 0, f"Concurrency isolation failed: {errors}"

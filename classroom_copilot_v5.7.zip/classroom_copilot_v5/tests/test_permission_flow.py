"""Permission-first action flow (v5.7): propose -> teacher yes/no -> act -> log.

Covers:
  - "2 plus 2 is 3" ingest creates a tier-3 PROPOSED event (the user's
    requirement: math errors must generate an event)
  - pending queue lists it; approve/deny close it with an audit trail
  - double-deciding returns 409
  - scripted noise reminders are pre-approved by default (no spam)
  - a school policy can pre-approve factual corrections for a lesson
  - low-confidence ASR events are logged silently, never proposed as spoken
"""
import os
import uuid
import pytest
from sqlalchemy import text

from app.db import tenant_session
from app.deps import get_principal
from app.main import app


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_lesson(super_session, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(
            text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"),
            {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]},
        )
    return lesson_id


def _ingest(client, two_schools, lesson_id, transcript, noise_db=45, confidence=None):
    payload = {
        "class_id": str(two_schools["class_a"]),
        "lesson_id": str(lesson_id),
        "transcript": transcript,
        "speaker": "teacher",
        "noise_db": noise_db,
    }
    if confidence is not None:
        payload["confidence"] = confidence
    return client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json=payload)


def test_math_error_generates_proposed_event(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    r = _ingest(client, two_schools, lesson_id, "2 plus 2 is 3")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "action_triggered"
    assert data["tier"] == 3
    assert data["approval_required"] is True
    assert "4" in data["proposal"]
    assert data["math"]["verdict"] == "error"

    # nothing is spoken until the teacher approves
    pend = client.get("/actions/pending", headers=auth(two_schools["token_a"]),
                      params={"lesson_id": str(lesson_id)}).json()
    assert len(pend) == 1
    assert pend[0]["action_type"] == "factual_correction"

    # approve it -> spoken_text released + status approved
    r2 = client.post(f"/actions/{data['action_id']}/approve",
                     headers=auth(two_schools["token_a"]), json={})
    assert r2.status_code == 200
    body = r2.json()
    assert body["status"] == "approved"
    assert "4" in body["spoken_text"]

    # approving again must fail cleanly
    r3 = client.post(f"/actions/{data['action_id']}/approve",
                     headers=auth(two_schools["token_a"]), json={})
    assert r3.status_code == 409

    # audit trail exists
    with tenant_session(two_schools["school_a"]) as db:
        logs = db.execute(text(
            "SELECT action FROM audit_logs WHERE resource = :res"),
            {"res": f"agent_action:{data['action_id']}"}).fetchall()
        assert any("action_approved" in row[0] for row in logs)


def test_deny_flow(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    r = _ingest(client, two_schools, lesson_id, "2 minus 2 is not equal to 0")
    data = r.json()
    assert data["tier"] == 3 and data["approval_required"] is True

    r2 = client.post(f"/actions/{data['action_id']}/deny",
                     headers=auth(two_schools["token_a"]), json={"note": "I'll handle it"})
    assert r2.status_code == 200
    assert r2.json()["status"] == "denied"

    pend = client.get("/actions/pending", headers=auth(two_schools["token_a"]),
                      params={"lesson_id": str(lesson_id)}).json()
    assert len(pend) == 0  # decided proposals leave the queue


def test_correct_math_creates_no_event(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    r = _ingest(client, two_schools, lesson_id, "2 plus 2 is 4")
    data = r.json()
    assert data["status"] == "processed"
    assert data["math_verified"] is True
    pend = client.get("/actions/pending", headers=auth(two_schools["token_a"]),
                      params={"lesson_id": str(lesson_id)}).json()
    assert len(pend) == 0


def test_noise_reminder_is_preapproved_by_default(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    r = _ingest(client, two_schools, lesson_id, "please open page 12", noise_db=80)
    data = r.json()
    assert data["status"] == "action_triggered"
    assert data["tier"] == 2
    assert data["approval_required"] is False


def test_policy_can_preapprove_corrections(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    app.dependency_overrides[get_principal] = lambda: {
        "sub": str(uuid.uuid4()), "school_id": str(two_schools["school_a"]),
        "role": "principal",
    }
    client.post("/policies", headers=auth("fake"), json={
        "name": "Auto-approve corrections",
        "config": {"auto_approve": ["scripted_reminder", "factual_correction"]},
    })
    app.dependency_overrides.clear()

    r = _ingest(client, two_schools, lesson_id, "2 plus 2 is 3")
    data = r.json()
    assert data["tier"] == 3
    assert data["approval_required"] is False  # pre-approved by policy


def test_low_confidence_is_logged_not_proposed(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    r = _ingest(client, two_schools, lesson_id, "2 plus 2 is 3", confidence=-0.9)
    data = r.json()
    assert data["status"] == "action_triggered"
    assert data["tier"] == 1                    # downgraded
    assert data["approval_required"] is False
    assert "Low ASR confidence" in data.get("note", "")


def test_pending_queue_is_tenant_scoped(client, two_schools, super_session):
    lesson_id = _make_lesson(super_session, two_schools)
    _ingest(client, two_schools, lesson_id, "2 plus 2 is 3")
    # school B must see nothing from school A's lesson
    r = client.get("/actions/pending", headers=auth(two_schools["token_b"]),
                   params={"lesson_id": str(lesson_id)})
    assert r.status_code == 200
    assert r.json() == []

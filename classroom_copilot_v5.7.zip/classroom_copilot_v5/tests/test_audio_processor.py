"""AudioProcessor pipeline: MathGuard -> AI brain -> confidence gate."""
from app.audio import AudioProcessor


def _chunk(transcript, noise_db=45, confidence=None):
    c = {"transcript": transcript, "noise_db": noise_db, "speaker": "teacher"}
    if confidence is not None:
        c["confidence"] = confidence
    return c


def test_math_error_becomes_tier3_event():
    r = AudioProcessor.process_chunk(_chunk("2 plus 2 is 3"), "school")
    assert r is not None
    assert r["action_type"] == "factual_correction"
    assert r["tier"] == 3
    assert "4" in r["suggestion"]
    assert r["meta"]["verdict"] == "error"
    assert r["meta"]["statement"]

def test_minus_two_not_equal_zero_becomes_event():
    r = AudioProcessor.process_chunk(_chunk("2 minus 2 is not equal to 0"), "school")
    assert r is not None
    assert r["action_type"] == "factual_correction"
    assert r["tier"] == 3
    assert r["meta"]["detector"] == "mathguard"

def test_garbled_fraction_produces_no_event():
    # mock brain must NOT fire on fraction keywords anymore
    r = AudioProcessor.process_chunk(
        _chunk("So one half is greater than three letters"), "school")
    assert r is None

def test_correct_math_is_reported_without_event():
    r = AudioProcessor.process_chunk(_chunk("2 plus 2 is 4"), "school")
    assert r is not None
    assert r["action_type"] == "math_verified"
    assert r["tier"] == 0
    assert r["meta"]["verdict"] == "correct"

def test_chatter_produces_no_event():
    assert AudioProcessor.process_chunk(_chunk("open your books to page 24"), "school") is None

def test_noise_triggers_scripted_reminder():
    r = AudioProcessor.process_chunk(_chunk("hello class", noise_db=80), "school")
    assert r is not None
    assert r["action_type"] == "scripted_reminder"
    assert r["tier"] == 2
    assert r["suggestion"]

def test_low_confidence_downgrades_correction_to_silent():
    r = AudioProcessor.process_chunk(_chunk("2 plus 2 is 3", confidence=-0.9), "school")
    assert r is not None
    assert r["tier"] == 1                      # downgraded from 3
    assert "Low ASR confidence" in r["reason"]
    assert r["meta"]["downgraded"] is True

def test_good_confidence_keeps_correction():
    r = AudioProcessor.process_chunk(_chunk("2 plus 2 is 3", confidence=-0.2), "school")
    assert r is not None
    assert r["tier"] == 3

def test_confidence_does_not_affect_noise_gate():
    r = AudioProcessor.process_chunk(_chunk("hello class", noise_db=90, confidence=-1.5), "school")
    assert r["tier"] == 2                      # measured dB, not ASR quality

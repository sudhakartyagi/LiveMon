import uuid
from sqlalchemy import text
from app.db import tenant_session
from app.deps import get_principal
from app.main import app

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_teacher_dashboard(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})
    
    client.post("/actions", headers=auth(two_schools["token_a"]), json={"lesson_id": str(lesson_id), "action_type": "recap", "reason": "Pacing check", "context": {}})
    r = client.get(f"/teacher/dashboard/{lesson_id}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 200
    assert len(r.json()) == 1
    assert r.json()[0]["action"] == "recap"

def test_principal_digest(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})

    # Use FastAPI's official dependency override
    app.dependency_overrides[get_principal] = lambda: {"sub": str(uuid.uuid4()), "school_id": str(two_schools["school_a"]), "role": "principal"}
    
    client.post("/actions", headers=auth("fake"), json={"lesson_id": str(lesson_id), "action_type": "teacher_absent", "reason": "Teacher absent > 3 min", "context": {"teacher_absent_minutes": 5}})
    r = client.get("/principal/digest", headers=auth("fake"))
    
    assert r.status_code == 200
    assert len(r.json()["action_items"]) >= 1
    
    app.dependency_overrides.clear()

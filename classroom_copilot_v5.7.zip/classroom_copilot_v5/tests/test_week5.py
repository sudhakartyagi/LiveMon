import uuid
from sqlalchemy import text
from app.db import tenant_session

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_praise_naming_disabled_by_default(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})
    
    # Try to praise name without policy opt-in
    r = client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id),
        "action_type": "praise_naming",
        "reason": "Good job",
        "target_student_id": str(two_schools["student_a"]),
        "context": {}
    })
    assert r.status_code == 403
    assert "disabled by school policy" in r.json()["detail"]

def test_praise_naming_enabled_by_policy(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})
    
    # Create policy enabling praise naming (Requires mocking principal role since token_a is a teacher)
    from app.deps import get_principal
    from app.main import app
    app.dependency_overrides[get_principal] = lambda: {"sub": str(uuid.uuid4()), "school_id": str(two_schools["school_a"]), "role": "principal"}
    
    client.post("/policies", headers=auth("fake"), json={
        "name": "Opt-in Policy",
        "config": {"allow_praise_naming": True}
    })
    
    # Now try as teacher
    app.dependency_overrides.clear()
    r = client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id),
        "action_type": "praise_naming",
        "reason": "Great work",
        "target_student_id": str(two_schools["student_a"]),
        "context": {}
    })
    assert r.status_code == 201
    assert r.json()["tier"] == 3 # Praise goes to digest (Tier 3)

def test_discipline_pattern_report(client, two_schools):
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), {"id": lesson_id, "sid": two_schools["school_a"], "cid": two_schools["class_a"]})

    # 1st Incident
    r1 = client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id), "action_type": "discipline_naming", "reason": "Talking",
        "target_student_id": str(two_schools["student_a"]), "context": {}
    })
    assert r1.json()["tier"] == 0 # Default is log only (Tier 0)

    # 2nd Incident
    client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id), "action_type": "discipline_naming", "reason": "Talking again",
        "target_student_id": str(two_schools["student_a"]), "context": {}
    })

    # 3rd Incident -> Should trigger Tier 4 Pattern Report
    r3 = client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id), "action_type": "discipline_naming", "reason": "Still talking",
        "target_student_id": str(two_schools["student_a"]), "context": {}
    })
    assert r3.json()["tier"] == 4
    assert r3.json()["requires_principal"] is True
    assert "Pattern threshold reached" in r3.json()["note"]

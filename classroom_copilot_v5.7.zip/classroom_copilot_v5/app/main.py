import uuid
from datetime import datetime, timezone, time, timedelta
from fastapi import FastAPI, Depends, HTTPException, Query
from app.db import tenant_session
from app.deps import get_principal
from app.models import Student, AgentAction, Policy, AuditLog, Dispute, Lesson, ClassState, CurriculumDoc
from app.schemas import PolicyCreate, ActionRequest, DisputeRequest, ApprovalDecision, AudioChunk, CurriculumUpload, RateRequest
from app.engine import PolicyEngine, Tier
from app.audio import AudioProcessor
from app.brain import AIBrain

app = FastAPI(title="Classroom Agent v5.7 (Voice + MathGuard + Permission-First)")

def _latest_policy_config(db) -> dict:
    policy = db.query(Policy).order_by(Policy.created_at.desc()).first()
    return policy.config if policy else {}

def _audit(db, school_id: str, actor: str, action: str, resource: str,
           cross_tenant: bool = False):
    db.add(AuditLog(school_id=uuid.UUID(school_id), actor_id=uuid.UUID(actor),
                    action=action, resource=resource,
                    is_cross_tenant_attempt=cross_tenant))

@app.get("/health")
def health():
    return {"status": "ok", "version": "5.7.0"}

@app.get("/students/{student_id}")
def get_student(student_id: uuid.UUID, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        student = db.get(Student, student_id)
        if student is None: raise HTTPException(404, "Not found")
        return {"id": str(student.id), "pseudonym": student.pseudonym}

@app.post("/curriculum/upload")
def upload_curriculum(data: CurriculumUpload, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        vector = AIBrain.get_embedding(data.content)
        doc = CurriculumDoc(school_id=uuid.UUID(principal["school_id"]), content=data.content, embedding=vector)
        db.add(doc)
        return {"status": "uploaded"}

@app.post("/policies", status_code=201)
def create_policy(policy: PolicyCreate, principal=Depends(get_principal)):
    if principal.get("role") not in ["admin", "principal"]: raise HTTPException(403, "Only principal/admin can set policies")
    with tenant_session(principal["school_id"]) as db:
        new_policy = Policy(school_id=uuid.UUID(principal["school_id"]), name=policy.name, config=policy.config)
        db.add(new_policy)
        db.flush()
        _audit(db, principal["school_id"], principal["sub"], "policy_created", f"policy:{new_policy.id}")
        return {"id": str(new_policy.id)}

@app.post("/actions", status_code=201)
def trigger_action(req: ActionRequest, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        policy = db.query(Policy).order_by(Policy.created_at.desc()).first()
        config = policy.config if policy else {}
        if req.action_type in ["praise_naming", "discipline_naming"]:
            if not req.target_student_id: raise HTTPException(400, f"{req.action_type} requires target_student_id")
            if req.action_type == "praise_naming" and not config.get("allow_praise_naming", False):
                raise HTTPException(403, "Praise naming is disabled by school policy")
            if req.action_type == "discipline_naming":
                thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
                recent = db.query(AgentAction).filter(AgentAction.action_type == "discipline_naming", AgentAction.target_id == str(req.target_student_id), AgentAction.created_at >= thirty_days_ago).count()
                if recent >= 2:
                    action = AgentAction(school_id=uuid.UUID(principal["school_id"]), lesson_id=req.lesson_id, action_type="pattern_report", tier=4, reason=f"Student {req.target_student_id} flagged 3 times in 30 days.", target_type="student", target_id=str(req.target_student_id), principal_notified=True)
                    db.add(action)
                    db.flush()
                    return {"id": str(action.id), "tier": 4, "requires_principal": True, "note": "Pattern threshold reached"}

        tier = PolicyEngine.route_action(req.action_type, req.context, config)
        action = AgentAction(school_id=uuid.UUID(principal["school_id"]), lesson_id=req.lesson_id, action_type=req.action_type, tier=tier, reason=req.reason, target_type="student" if req.target_student_id else None, target_id=str(req.target_student_id) if req.target_student_id else None, principal_notified=(tier == 4))
        db.add(action)
        db.flush()
        return {"id": str(action.id), "tier": tier, "requires_principal": (tier == 4)}

@app.post("/actions/{action_id}/approve")
def approve_action(action_id: uuid.UUID, req: ApprovalDecision = None,
                   principal=Depends(get_principal)):
    """Teacher says YES to a proposed action — only now may it be spoken/shown."""
    with tenant_session(principal["school_id"]) as db:
        action = db.get(AgentAction, action_id)
        if not action: raise HTTPException(404, "Action not found")
        if action.status != "proposed":
            raise HTTPException(409, f"Action is not pending approval (status: {action.status})")
        action.status = "approved"
        action.approved_by = uuid.UUID(principal["sub"])
        action.decided_at = datetime.now(timezone.utc)
        _audit(db, principal["school_id"], principal["sub"],
               "action_approved", f"agent_action:{action.id}")
        return {
            "id": str(action.id), "status": "approved",
            "spoken_text": action.proposed_text,
            "action_type": action.action_type, "tier": action.tier,
        }

@app.post("/actions/{action_id}/deny")
def deny_action(action_id: uuid.UUID, req: ApprovalDecision = None,
                principal=Depends(get_principal)):
    """Teacher says NO — the proposal is logged, never spoken."""
    with tenant_session(principal["school_id"]) as db:
        action = db.get(AgentAction, action_id)
        if not action: raise HTTPException(404, "Action not found")
        if action.status != "proposed":
            raise HTTPException(409, f"Action is not pending approval (status: {action.status})")
        action.status = "denied"
        action.approved_by = uuid.UUID(principal["sub"])
        action.decided_at = datetime.now(timezone.utc)
        _audit(db, principal["school_id"], principal["sub"],
               "action_denied", f"agent_action:{action.id}")
        return {"id": str(action.id), "status": "denied", "action_type": action.action_type}

@app.get("/actions/pending")
def pending_actions(lesson_id: uuid.UUID = Query(...), principal=Depends(get_principal)):
    """Proposals awaiting the teacher's yes/no (permission-first queue)."""
    with tenant_session(principal["school_id"]) as db:
        rows = (db.query(AgentAction)
                .filter(AgentAction.lesson_id == lesson_id,
                        AgentAction.status == "proposed")
                .order_by(AgentAction.created_at.desc()).all())
        return [{
            "id": str(a.id),
            "time": a.created_at.strftime("%H:%M:%S") if a.created_at else None,
            "action_type": a.action_type,
            "tier": a.tier,
            "reason": a.reason,
            "proposal": a.proposed_text,
            "meta": a.meta,
        } for a in rows]

@app.post("/actions/{action_id}/flag", status_code=201)
def flag_action(action_id: uuid.UUID, req: DisputeRequest, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        action = db.get(AgentAction, action_id)
        if not action: raise HTTPException(404, "Action not found")
        dispute = Dispute(school_id=uuid.UUID(principal["school_id"]), agent_action_id=action.id, teacher_id=uuid.UUID(principal["sub"]), flag_reason=req.flag_reason, resolution="agent_wrong" if action.tier >= 3 else "agent_right")
        db.add(dispute)
        action.status = "flagged"
        _audit(db, principal["school_id"], principal["sub"], "action_flagged", f"agent_action:{action.id}")
        return {"dispute_id": str(dispute.id), "resolution": dispute.resolution}

@app.post("/actions/{action_id}/rate")
def rate_action(action_id: uuid.UUID, req: RateRequest, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        action = db.get(AgentAction, action_id)
        if not action: raise HTTPException(404, "Action not found")
        action.status = f"rated_{req.rating}"
        return {"status": "success", "action_status": action.status}

@app.get("/teacher/dashboard/{lesson_id}")
def teacher_dashboard(lesson_id: uuid.UUID, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        actions = db.query(AgentAction).filter(AgentAction.lesson_id == lesson_id).order_by(AgentAction.created_at.desc()).all()
        return [{"id": str(a.id), "time": a.created_at.strftime("%H:%M:%S"), "action": a.action_type, "tier": a.tier, "reason": a.reason, "status": a.status, "proposal": a.proposed_text, "meta": a.meta} for a in actions]

@app.get("/principal/digest")
def principal_digest(date: str = None, principal=Depends(get_principal)):
    if principal.get("role") not in ["principal", "admin"]: raise HTTPException(403, "Access denied. Principal only.")
    if not date: target_date = datetime.now(timezone.utc).date()
    else:
        try: target_date = datetime.strptime(date, "%Y-%m-%d").date()
        except ValueError: raise HTTPException(400, "Invalid date format. Use YYYY-MM-DD")
    start_of_day = datetime.combine(target_date, time.min)
    end_of_day = datetime.combine(target_date, time.max)

    with tenant_session(principal["school_id"]) as db:
        action_items = db.query(AgentAction).filter(AgentAction.tier == 4, AgentAction.created_at >= start_of_day, AgentAction.created_at <= end_of_day).all()
        disputes = db.query(Dispute).filter(Dispute.created_at >= start_of_day).all()
        discipline_flags = db.query(AgentAction).filter(AgentAction.action_type == "discipline_naming", AgentAction.created_at >= start_of_day).all()
        return {"date": str(target_date), "action_items": [{"id": str(a.id), "type": a.action_type, "reason": a.reason, "status": a.status} for a in action_items], "disputes": [{"id": str(d.id), "reason": d.flag_reason, "resolution": d.resolution} for d in disputes], "discipline_flags": [{"id": str(a.id), "action": a.action_type, "status": a.status} for a in discipline_flags]}

@app.post("/audio/ingest")
def ingest_audio(chunk: AudioChunk, principal=Depends(get_principal)):
    """Voice event pipeline (permission-first).

    - MathGuard verifies arithmetic claims deterministically.
    - Errors become tier-3 factual_correction EVENTS (proposed; the teacher
      must allow them before anything is spoken — nothing is stored beyond
      the structured event: raw transcripts are never persisted).
    - Low-confidence ASR is downgraded to a silent log (never spoken).
    - Correct math gets a math_verified note and creates no event.
    """
    with tenant_session(principal["school_id"]) as db:
        state = db.query(ClassState).filter(ClassState.class_id == chunk.class_id).first()
        if state and state.is_paused: return {"status": "ignored", "reason": "Agent is paused"}
        result = AudioProcessor.process_chunk(chunk.model_dump(), principal["school_id"])
        if not result:
            return {"status": "processed", "action": None}

        # verified-correct math: report only, no event row
        if result.get("action_type") == "math_verified":
            return {"status": "processed", "action": None, "math_verified": True,
                    "note": result.get("reason"), "math": result.get("meta")}

        tier = int(result.get("tier", Tier.OBSERVE))
        action_type = result.get("action_type", "unknown")
        config = _latest_policy_config(db)
        approval_required = PolicyEngine.needs_approval(tier, action_type, config)

        if tier >= Tier.ESCALATE:
            status = "escalated"
        elif approval_required:
            status = "proposed"
        elif tier <= Tier.SILENT:
            status = "logged"
        else:
            status = "executed"

        action = AgentAction(
            school_id=uuid.UUID(principal["school_id"]),
            lesson_id=chunk.lesson_id,
            action_type=action_type,
            tier=tier,
            reason=result.get("reason", "")[:500],
            status=status,
            proposed_text=result.get("suggestion"),
            meta=result.get("meta"),
            principal_notified=(tier >= Tier.ESCALATE),
        )
        db.add(action)
        db.flush()

        response = {"status": "action_triggered", "action_id": str(action.id),
                    "tier": tier, "reason": result.get("reason", ""),
                    "approval_required": approval_required}
        if result.get("meta"):
            response["math"] = result["meta"]
        if approval_required:
            response["proposal"] = result.get("suggestion")
            response["teacher_note"] = ("Nothing will be said to the class until "
                                        "you approve this in the dashboard.")
        if result.get("note"):
            response["note"] = result["note"]
        return response

@app.post("/agent/pause/{class_id}")
def pause_agent(class_id: uuid.UUID, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        state = db.query(ClassState).filter(ClassState.class_id == class_id).first()
        if not state:
            state = ClassState(school_id=uuid.UUID(principal["school_id"]), class_id=class_id, is_paused=True, paused_at=datetime.now(timezone.utc))
            db.add(state)
        else:
            state.is_paused = True
            state.paused_at = datetime.now(timezone.utc)
        return {"status": "paused", "class_id": str(class_id)}

@app.post("/agent/resume/{class_id}")
def resume_agent(class_id: uuid.UUID, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        state = db.query(ClassState).filter(ClassState.class_id == class_id).first()
        if state:
            state.is_paused = False
            state.paused_at = None
        return {"status": "resumed", "class_id": str(class_id)}

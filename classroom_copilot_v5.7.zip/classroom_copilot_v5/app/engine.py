from enum import IntEnum
from typing import Dict, Any


class Tier(IntEnum):
    OBSERVE = 0
    SILENT = 1
    ACT = 2
    CORRECT = 3
    ESCALATE = 4


class PolicyEngine:
    """Tier routing + permission-first gating.

    Core design rule (product context): Propose -> permission -> act -> log.
    Nothing is spoken or shown to the class until the teacher allows it,
    UNLESS the school pre-approved that action type in its policy config.
    """

    # The first five allowed agent actions (product decision, v5.7)
    PERMISSION_FIRST_ACTIONS = [
        "recap", "example", "check_question", "quiet_reminder", "timer",
    ]

    DEFAULTS: Dict[str, int] = {
        # permission-first five
        "timer": Tier.ACT, "recap": Tier.ACT, "example": Tier.ACT,
        "check_question": Tier.ACT, "quiet_reminder": Tier.ACT,
        # monitoring signals
        "common_mistake": Tier.ACT, "language_nudge": Tier.ACT,
        "scripted_reminder": Tier.ACT,
        # corrections & individual references
        "factual_correction": Tier.CORRECT, "praise_naming": Tier.CORRECT,
        "teaching_suggestion": Tier.ACT, "individual_hint": Tier.SILENT,
        # discipline: observe/log only — never autonomous punishment
        "discipline_naming": Tier.OBSERVE,
    }

    # Whole-class, non-naming reminders are pre-approved by default so the
    # pilot is usable out of the box; everything else needs teacher approval.
    DEFAULT_AUTO_APPROVE = ["scripted_reminder"]

    @staticmethod
    def route_action(action_type: str, context: Dict[str, Any], policy_config: dict) -> int:
        if context.get("teacher_absent_minutes", 0) > 3:
            return Tier.ESCALATE
        if context.get("safety_event"):
            return Tier.ESCALATE
        rules = policy_config.get("rules", {})
        if action_type in rules:
            return int(rules[action_type])
        return PolicyEngine.DEFAULTS.get(action_type, Tier.OBSERVE)

    @staticmethod
    def needs_approval(tier: int, action_type: str, policy_config: dict) -> bool:
        """True when the agent must ASK before acting on this event."""
        if tier < Tier.ACT:
            return False          # tier 0/1 are log-only, nothing to approve
        if tier >= Tier.ESCALATE:
            return False          # tier 4 goes to the principal digest, not the mic
        auto = policy_config.get("auto_approve")
        if auto is None:
            auto = PolicyEngine.DEFAULT_AUTO_APPROVE
        return action_type not in auto

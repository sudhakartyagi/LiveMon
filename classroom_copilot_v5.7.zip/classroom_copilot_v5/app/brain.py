import os
import re
from sqlalchemy import text
from app.db import tenant_session

# Explicit teaching requests the conservative mock may respond to.
_REQUEST_RE = re.compile(
    r"\b(give|tell|show|need|want|suggest|share)(\s+(us|me))?\b.{0,30}\b(example|analogy|idea)\b"
    r"|\bwhat\s+(is|about)\s+(an?|the)\s+(example|analogy)\b"
    r"|\bexplain\s+(this|that|it|again|once more|differently)\b"
    r"|\bhow\s+(do|does|can|should)\s+i\s+(explain|teach|show)\b",
    re.IGNORECASE,
)


class AIBrain:
    """Curriculum-grounded guidance layer.

    analyze_misconception returns a STRUCTURED dict (never raises):
        {"kind": "correction"|"suggestion", "text": str, "source": str}
    or None when the transcript is ordinary classroom chatter.

    Note: deterministic math verification lives in app.mathguard and runs
    BEFORE this class (see app.audio.AudioProcessor) — the old keyword mock
    that fired on "half"/"greater" (the false-positive source) is gone.
    """

    @staticmethod
    def get_embedding(text: str) -> list:
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key and "your-actual" not in api_key and api_key.startswith("sk-"):
            try:
                from openai import OpenAI
                client = OpenAI()
                response = client.embeddings.create(input=text, model="text-embedding-3-small")
                return response.data[0].embedding
            except Exception as e:
                print(f"⚠️ OpenAI Embedding failed: {e}")

        if os.getenv("OLLAMA_HOST"):
            try:
                import ollama
                response = ollama.embeddings(model='nomic-embed-text', prompt=text)
                return response['embedding']
            except Exception:
                pass

        return [float(hash(text + str(i)) % 100) / 100.0 for i in range(1536)]

    @staticmethod
    def _vector_literal(vec: list) -> str:
        """pgvector text form: '[0.1,0.2,...]' (str(list) with spaces and
        Python repr quirks is not accepted reliably by the <=> operator)."""
        return "[" + ",".join(f"{float(x):.6f}" for x in vec) + "]"

    @staticmethod
    def _curriculum_context(transcript: str, school_id: str) -> str:
        query_vector = AIBrain.get_embedding(transcript)
        try:
            with tenant_session(school_id) as db:
                results = db.execute(
                    text("SELECT content FROM curriculum_docs ORDER BY embedding <=> :vec LIMIT 1"),
                    {"vec": AIBrain._vector_literal(query_vector)},
                ).fetchone()
                if results:
                    return results[0]
        except Exception as e:
            print(f"DB RAG Error: {e}")
        return ""

    @staticmethod
    def analyze_misconception(transcript: str, school_id: str):
        context = AIBrain._curriculum_context(transcript, school_id)

        prompt = f"""You are an AI classroom co-pilot for Class 4-5 (Indian school). The teacher just said: "{transcript}"
Curriculum Context: {context}

Rules:
1. If the teacher made a factual/math error, respond with a POLITE HINT that points to the right answer without shaming anyone (hints, not spoon-feeding). Prefix with CORRECTION:.
2. If the teacher is asking for help (example, analogy, better explanation), give ONE concrete curriculum-grounded suggestion under 2 sentences. Prefix with SUGGESTION:.
3. If it is ordinary classroom chatter or instruction (e.g., "open your books"), output exactly: None
4. Never name or single out any student. Never discuss behaviour."""

        api_key = os.getenv("OPENAI_API_KEY")
        if api_key and "your-actual" not in api_key and api_key.startswith("sk-"):
            try:
                from openai import OpenAI
                client = OpenAI()
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=120,
                )
                return AIBrain._parse_llm(response.choices[0].message.content, "openai")
            except Exception as e:
                print(f"⚠️ OpenAI Chat failed: {e}")

        if os.getenv("OLLAMA_HOST"):
            try:
                import ollama
                response = ollama.chat(model='llama3', messages=[{'role': 'user', 'content': prompt}])
                return AIBrain._parse_llm(response['message']['content'], "ollama")
            except Exception as e:
                print(f"⚠️ Ollama Chat failed: {e}")

        return AIBrain._mock(transcript, context)

    @staticmethod
    def _parse_llm(raw: str, source: str):
        if not raw:
            return None
        text_out = raw.strip()
        if text_out.lower() == "none" or not text_out:
            return None
        # strip an optional leading "CORRECTION:" / "SUGGESTION:" marker
        kind = "suggestion"
        m = re.match(r"^\s*(correction|suggestion)\s*:\s*(.+)$", text_out, re.IGNORECASE | re.DOTALL)
        if m:
            kind = m.group(1).lower()
            text_out = m.group(2).strip()
        return {"kind": kind, "text": text_out, "source": source}

    @staticmethod
    def _mock(transcript: str, context: str):
        """Conservative offline fallback.

        NO keyword triggers on math words (that was the false-positive
        source). Only an explicit teaching request produces a suggestion;
        everything else is chatter -> None."""
        if _REQUEST_RE.search(transcript or ""):
            ctx = context.strip() or "the current chapter"
            return {
                "kind": "suggestion",
                "text": f"[Mock AI] Example for the class: {ctx}",
                "source": "mock",
            }
        return None

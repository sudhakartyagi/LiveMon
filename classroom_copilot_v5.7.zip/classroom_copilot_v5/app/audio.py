from typing import Optional

import os
import re

from app.engine import Tier
from app.brain import AIBrain
from app.mathguard import MathVerdict, check as math_check

# Tunable via environment so schools can tighten/loosen without code changes
NOISE_ALERT_DB = int(os.getenv("NOISE_ALERT_DB", "75"))
MIN_WORDS_FOR_AI = 3

# Below this average Whisper log-prob the transcript is considered unreliable.
# Unreliable transcripts may be LOGGED but must never auto-fire a tier-3
# correction (the "one half is greater than three letters" false-positive
# class). Scale: Whisper avg_logprob ~ -0.1 (clean) .. -1.5 (garbage).
CONFIDENCE_FLOOR = float(os.getenv("ASR_CONFIDENCE_FLOOR", "-0.6"))

LOW_CONF_NOTE = "Low ASR confidence — logged for review only, not spoken."

_SCRIPTED_NOISE_LINE = "May I remind everyone to keep the class quiet for a moment?"

_WS_RE = re.compile(r"\s+")


class AudioProcessor:
    """Decides what a transcribed chunk means for the classroom agent.

    Pipeline (order matters):

      1. normalize transcript
      2. noise gate           -> tier 2 scripted_reminder (whole-class, safe)
      3. MathGuard            -> deterministic math verification:
           error              -> tier 3 factual_correction event (proposed,
                                 teacher must approve before it is spoken)
           correct            -> math_verified note, no event
           no claim parsed    -> fall through to the AI brain
      4. AI brain (LLM or conservative mock) -> suggestion / correction
      5. confidence gate      -> low-confidence ASR downgrades tier 3 to
                                 tier 1 (log only), never auto-spoken

    The returned dict is structured so /audio/ingest can persist a proper
    event and run the permission-first flow:

      {action_type, tier, reason, suggestion?, meta?, note?}
    """

    @staticmethod
    def process_chunk(chunk: dict, school_id: str) -> Optional[dict]:
        raw = chunk.get("transcript") or ""
        transcript = _WS_RE.sub(" ", raw).strip()
        noise = chunk.get("noise_db", 0) or 0
        confidence = chunk.get("confidence")

        # 1. Noise gate (measured dB, independent of ASR quality)
        if noise > NOISE_ALERT_DB:
            return {
                "action_type": "scripted_reminder",
                "tier": Tier.ACT,
                "reason": f"Ambient noise exceeded threshold ({noise}dB)",
                "suggestion": _SCRIPTED_NOISE_LINE,
                "meta": {"noise_db": noise},
            }

        if not transcript:
            return None

        # 2. Deterministic math verification (free, instant, no LLM)
        verdict: Optional[MathVerdict] = None
        try:
            verdict = math_check(transcript)
        except Exception as e:  # MathGuard must never break ingest
            print(f"❌ MathGuard error: {e}")

        if verdict is not None:
            if verdict.status == "error":
                event = {
                    "action_type": "factual_correction",
                    "tier": Tier.CORRECT,
                    "reason": verdict.explanation,
                    "suggestion": verdict.correction,
                    "meta": {
                        "kind": verdict.kind,
                        "topic": verdict.topic,
                        "statement": verdict.statement,
                        "verdict": "error",
                        "detector": "mathguard",
                    },
                }
                return AudioProcessor._confidence_gate(event, confidence)
            # correct math — report in the response, create no event
            return {
                "action_type": "math_verified",
                "tier": Tier.OBSERVE,
                "reason": verdict.explanation,
                "meta": {
                    "kind": verdict.kind,
                    "topic": verdict.topic,
                    "statement": verdict.statement,
                    "verdict": "correct",
                    "detector": "mathguard",
                },
            }

        # 3. Fall through to the AI brain for non-math guidance
        if len(transcript.split()) > MIN_WORDS_FOR_AI:
            try:
                ai_response = AIBrain.analyze_misconception(transcript, school_id)
            except Exception as e:  # never break the ingest path
                print(f"❌ AIBrain error: {e}")
                return None
            if ai_response and isinstance(ai_response, dict):
                text = str(ai_response.get("text") or "").strip()
                kind = ai_response.get("kind") or "suggestion"
                if text and text.lower() != "none":
                    event = {
                        "action_type": "factual_correction"
                        if kind == "correction" else "teaching_suggestion",
                        "tier": Tier.CORRECT if kind == "correction" else Tier.ACT,
                        "reason": text,
                        "suggestion": text,
                        "meta": {"detector": ai_response.get("source", "ai")},
                    }
                    return AudioProcessor._confidence_gate(event, confidence)

        return None

    @staticmethod
    def _confidence_gate(event: dict, confidence: Optional[float]) -> dict:
        """Low-confidence ASR must never auto-fire an intervention.

        Tier 3+ events from unreliable transcripts are downgraded to tier 1
        (silent log for teacher review). Tier 0-2 are untouched."""
        if confidence is not None and event.get("tier", 0) >= Tier.CORRECT \
                and confidence < CONFIDENCE_FLOOR:
            downgraded = dict(event)
            downgraded["tier"] = Tier.SILENT
            downgraded["reason"] = f"[{LOW_CONF_NOTE}] {event.get('reason', '')}"
            downgraded["meta"] = dict(event.get("meta") or {})
            downgraded["meta"]["asr_confidence"] = confidence
            downgraded["meta"]["downgraded"] = True
            downgraded["note"] = LOW_CONF_NOTE
            return downgraded
        if confidence is not None:
            event.setdefault("meta", {})["asr_confidence"] = confidence
        return event

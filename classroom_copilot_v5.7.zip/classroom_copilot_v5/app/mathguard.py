"""
mathguard.py — deterministic spoken-math verification for the classroom agent.

WHY THIS EXISTS
---------------
The old pipeline sent every transcript to a keyword mock that fired on words
like "half" / "greater" (false positives on "one half is greater than three
letters") while real math errors — "2 plus 2 is 3", "2 minus 2 is not equal
to 0" — produced NO event. MathGuard fixes both directions:

  1. Real errors produce a structured event (tier 3 factual_correction).
  2. Garbage/ambiguous text parses to NOTHING (no event, no false alarm).

It is fully deterministic (no LLM, no network, zero cost, ~microseconds) so
it runs first on every transcript; the LLM brain is only consulted for text
MathGuard cannot parse.

WHAT IT UNDERSTANDS (Class 4–5 spoken math, Indian classroom included)
----------------------------------------------------------------------
  "2 plus 2 is 3"                      -> ERROR  (2 + 2 = 4)
  "2 minus 2 is not equal to 0"        -> ERROR  (2 - 2 = 0, so it IS equal)
  "one half is greater than one third" -> correct (no event)
  "1/2 is bigger than 3/4"             -> ERROR  (0.5 < 0.75)
  "2 into 3 is 6"                      -> correct ("into" = multiply)
  "do plus do is chaar"                -> correct (Hinglish numerals)
  "twenty five plus seventy five is one hundred" -> correct
  "2 divided by 0 is 0"                -> ERROR  (division by zero)
  "half of 10 is 5"                    -> correct
  "two thirds of 90 is 60"             -> correct
  "10 minus 15 is minus 5"             -> correct (unary minus)
  "sum of 2 and 3 is 5"                -> correct
  "5 subtracted from 9 is 4"           -> correct (order handled)
  "3 by 4 is smaller than 1 by 2"      -> ERROR  ("3 by 4" = 3/4)
  "what is 2 plus 2?"                  -> None   (a question, not a claim)
  "let's move to page 42"              -> None   (no claim)

Only a FULL claim of the form  <expression> <relation> <expression>  produces
a verdict; anything else returns None and falls through to the AI brain.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import List, Optional, Tuple

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class MathVerdict:
    """Outcome of checking one transcript for a math claim."""

    status: str            # "error" | "correct"
    kind: str              # arithmetic_error | comparison_error | division_by_zero | correct_arithmetic | correct_comparison
    statement: str         # human-readable claim, e.g. "2 plus 2 is 3"
    explanation: str       # teacher-facing reason (goes into the event)
    correction: str = ""   # suggested correct statement (errors only)
    topic: str = "arithmetic"


# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

# English number words (unambiguous ones only get global substitution)
_UNITS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19,
}
_TENS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60,
    "seventy": 70, "eighty": 80, "ninety": 90,
}
_SCALES = {"hundred": 100, "thousand": 1000}

# Hinglish numerals (common in Indian classrooms; pattern-protected so the
# English word "do" can never be misread outside a full arithmetic claim)
_HINDI = {
    "ek": 1, "do": 2, "teen": 3, "char": 4, "chaar": 4, "paanch": 5,
    "panch": 5, "chhe": 6, "chhah": 6, "saat": 7, "aath": 8, "nau": 9,
    "das": 10, "bees": 20,
}

# Homophones Whisper confuses — substituted ONLY in a second, contextual pass
# (operand slot next to an operator/relation), never globally.
_HOMOPHONES = {"to": 2, "too": 2, "for": 4, "won": 1, "ate": 8}

_FRACTION_DENOMS = {
    "half": 2, "halves": 2, "third": 3, "thirds": 3, "fourth": 4,
    "fourths": 4, "quarter": 4, "quarters": 4, "fifth": 5, "fifths": 5,
    "sixth": 6, "sixths": 6, "eighth": 8, "eighths": 8, "tenth": 10,
    "tenths": 10,
}
_NUM_WORDS_FOR_FRACTIONS = dict(_UNITS)
_NUM_WORDS_FOR_FRACTIONS.update({"a": 1})

_OP_WORDS = {"plus": "+", "add": "+", "minus": "-", "subtract": "-",
             "take": None}  # "take away" handled as phrase
_REL_TEXT = {"=": "is", "!=": "is not equal to", ">": "greater than",
             "<": "less than"}

# ---------------------------------------------------------------------------
# Normalization stages
# ---------------------------------------------------------------------------

_FILLER_RE = re.compile(
    r"\b(ok|okay|so|then|well|um|uh|hmm|ah|actually|see|look|now|please|"
    r"children|students|bacho|baccho|dear)\b", re.IGNORECASE)


def _strip_punct(text: str) -> str:
    # keep digits, letters, dot, slash; commas/!? act as separators -> space
    text = re.sub(r"[^a-z0-9./\s]", " ", text.lower())
    return re.sub(r"\s+", " ", text).strip()


def _fill_fraction_phrases(text: str) -> str:
    """one half -> 1/2 ; three fourths -> 3/4 ; two thirds -> 2/3 ;
    bare 'half' -> 1/2 ; bare 'quarter/quarters' -> 1/4 ;
    'two halves' -> 1 (two 1/2s make one whole)."""
    num = r"(one|two|three|four|five|six|seven|eight|nine|ten|a)"
    den = r"(halves|half|thirds|third|fourths|fourth|quarters|quarter|fifths|fifth|sixths|sixth|eighths|eighth|tenths|tenth)"

    def repl(m: re.Match) -> str:
        n = _NUM_WORDS_FOR_FRACTIONS.get(m.group(1), 1)
        d = _FRACTION_DENOMS[m.group(2)]
        val = Fraction(n, 1) * Fraction(1, d)
        return f"{val.numerator}/{val.denominator}"

    text = re.sub(rf"\b{num}\s+{den}\b", repl, text)
    text = re.sub(r"\bhalves\b", "1/2", text)
    text = re.sub(r"\bhalf\b", "1/2", text)
    text = re.sub(r"\bquarters?\b", "1/4", text)
    return text


def _compose_number_words(text: str) -> str:
    """Replace runs of number words with digits.

    'twenty five' -> 25 ; 'one hundred and five' -> 105 ('and' continues a
    number only after a scale word) ; 'two point five' -> 2.5 ; Hinglish
    numerals included. Ambiguous homophones are NOT touched here.
    """
    vocab = {}
    vocab.update(_UNITS)
    vocab.update(_TENS)
    vocab.update(_SCALES)
    vocab.update(_HINDI)

    tokens = text.split()
    out: List[str] = []
    run: List[str] = []           # current number-word run
    run_val = 0
    run_used_scale = False
    decimal_mode = False
    frac_part = ""

    def flush():
        nonlocal run, run_val, run_used_scale, decimal_mode, frac_part
        if run:
            if decimal_mode and frac_part:
                out.append(f"{run_val}.{frac_part}")
            else:
                out.append(str(run_val))
        run, run_val, run_used_scale = [], 0, False
        decimal_mode, frac_part = False, ""

    i = 0
    n = len(tokens)
    while i < n:
        tok = tokens[i]
        if tok == "point" and run:
            # decimal point inside a spoken number: "two point five"
            if i + 1 < n and tokens[i + 1] in vocab and vocab[tokens[i + 1]] < 10:
                decimal_mode = True
                i += 1
                continue
        if tok == "and" and run and run_used_scale:
            # 'one hundred AND five' continues the run; 'two and three' does not
            nxt = tokens[i + 1] if i + 1 < n else None
            if nxt in vocab and vocab[nxt] < _SCALES.get("hundred", 100) * 10:
                i += 1
                continue
        if tok in vocab:
            val = vocab[tok]
            if decimal_mode:
                frac_part += str(val)
            elif tok in _SCALES:
                scale = _SCALES[tok]
                run_val = (run_val if run_val else 1) * scale
                run_used_scale = True
            else:
                if run_val % 10 and run_val >= 20 and not run_used_scale:
                    # 'twenty five' style composition
                    run_val += val
                elif run_val and run_val < 20:
                    # 'ten five' — unusual; treat as separate numbers
                    flush()
                    run_val = val
                else:
                    run_val += val
            run.append(tok)
        else:
            flush()
            out.append(tok)
        i += 1
    flush()
    return " ".join(out)


def _normalize_relations(text: str) -> str:
    # 1. negations first ("is not equal to" before "is not")
    neg = [
        r"is not equal to", r"isn'?t equal to", r"not equal to",
        r"does not equal", r"doesn'?t equal", r"doesnot equal",
        r"is not", r"isn'?t", r"are not", r"aren'?t", r"not same as",
    ]
    for p in neg:
        text = re.sub(rf"\b{p}\b", " != ", text)
    # 2. copula-anchored comparisons. Comparisons REQUIRE 'is/are' so that
    #    bare phrases like "3 less than 5" (often meaning 5-3) never produce
    #    a false claim. 'then' variants cover Whisper mishearings.
    text = re.sub(r"\b(?:is|are)\s+(?:greater|more|bigger|larger|higher)\s+th[ae]n\b", " > ", text)
    text = re.sub(r"\b(?:is|are)\s+(?:less|smaller|lesser|fewer|lower)\s+th[ae]n\b", " < ", text)
    # 3. positive equality phrases
    pos = [
        r"is equal to", r"are equal to", r"equals to", r"equal to",
        r"equals", r"is same as", r"same as",
    ]
    for p in pos:
        text = re.sub(rf"\b{p}\b", " = ", text)
    # 4. standalone copulas LAST (so they never split a comparison phrase)
    text = re.sub(r"\b(?:is|are|makes|gives|will be|would be|comes to|comes out to|comes out as|becomes)\b", " = ", text)
    return text


def _normalize_operators(text: str) -> str:
    # multi-word pre-transforms (order matters)
    text = re.sub(r"\bsum of\s+(-?[\d./]+)\s+and\s+(-?[\d./]+)", r"\1 + \2", text)
    text = re.sub(r"\bdifference (?:between|of)\s+(-?[\d./]+)\s+and\s+(-?[\d./]+)", r"\1 - \2", text)
    text = re.sub(r"\bproduct of\s+(-?[\d./]+)\s+and\s+(-?[\d./]+)", r"\1 * \2", text)
    text = re.sub(r"\b(-?[\d./]+)\s+added to\s+(-?[\d./]+)", r"\2 + \1", text)
    text = re.sub(r"\b(-?[\d./]+)\s+(?:subtracted from|taken away from|take away from)\s+(-?[\d./]+)", r"\2 - \1", text)
    text = re.sub(r"\b(?:double|twice)\s+(?:of\s+)?(-?[\d./]+)", r"\1 * 2", text)

    # 'fraction of N' handled at claim level; simple ops now:
    text = re.sub(r"\b(?:plus|added with|summed with)\b", " + ", text)
    text = re.sub(r"\b(?:minus|subtract|take away)\b", " - ", text)
    text = re.sub(r"\b(?:into|times|multiplied by|multiplied with|multiplied)\b", " * ", text)
    text = re.sub(r"\b(?:divided by|divided)\b", " / ", text)
    text = re.sub(r"\b(?:upon|over)\b", " / ", text)
    # '3 by 4' as a fraction/answer — only between digits
    text = re.sub(r"(?<=\d)\s+by\s+(?=\d)", " / ", text)
    # 'and' as plus ONLY between two numbers ('two and three' -> '2 + 3')
    text = re.sub(r"(?<=\d)\s+and\s+(?=\d)", " + ", text)
    # unary minus after a relation: 'is minus 5' -> '= -5'
    text = re.sub(r"([=!<>]=?)\s+(?:minus|negative)\s+", r"\1 -", text)
    return text


_NUM_TOKEN = r"-?\d+(?:\.\d+)?(?:/\d+(?:\.\d+)?)?"
_RUN_TOKEN = re.compile(rf"({ _NUM_TOKEN }|!=|[+\-*/=<>])")


def _longest_token_run(text: str) -> Optional[str]:
    """Extract the longest contiguous run of number/operator/relation tokens.

    Filler words around the claim ('so', 'the answer', ...) simply break runs;
    the longest VALID run is taken as the claim. A run is invalid when a real
    word immediately follows it ("1/2 > 3 letters", "42 page") — a number
    trailed by a noun is not the end of a spoken claim."""
    best = ""
    for m in _RUN_TOKEN.finditer(text):
        start = m.start()
        end = start
        pieces = []
        for m2 in _RUN_TOKEN.finditer(text, start):
            gap_text = text[end:m2.start()]
            if gap_text.strip():        # non-claim word in between -> stop run
                break
            pieces.append(m2.group(0))
            end = m2.end()
        # trailing-word guard: an alphabetic word right after the run means
        # the run ended mid-phrase ("3 letters") -> not a complete claim
        rest = text[end:].lstrip()
        if rest and rest[0].isalpha():
            continue
        run = " ".join(pieces)
        if len(run) > len(best):
            best = run
    best = best.strip()
    return best or None


# ---------------------------------------------------------------------------
# Parsing + evaluation of the claim run
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(rf"{_NUM_TOKEN}|!=|[+\-*/=<>]")


def _tokenize_run(run: str) -> List[str]:
    return _TOKEN_RE.findall(run)


def _to_fraction(tok: str) -> Optional[Fraction]:
    tok = tok.strip()
    try:
        if "/" in tok:
            num, den = tok.split("/")
            return Fraction(float(num)).limit_denominator(10**6) / Fraction(float(den)).limit_denominator(10**6)
        return Fraction(float(tok)).limit_denominator(10**6)
    except (ValueError, ZeroDivisionError):
        return None


def _eval_expr(tokens: List[str], i: int = 0) -> Tuple[Optional[Fraction], int, Optional[str]]:
    """Recursive-descent: expr := term (('+'|'-') term)*; term := factor (('*'|'/') factor)*; factor := ['-'] NUM.

    Returns (value, next_index, error_kind). Implicit multiplication is NOT
    allowed — two numbers in a row is a parse failure."""
    val, i, err = _eval_term(tokens, i)
    if err:
        return None, i, err
    while i < len(tokens) and tokens[i] in "+-":
        op = tokens[i]
        rhs, j, err = _eval_term(tokens, i + 1)
        if err:
            return None, j, err
        val = val + rhs if op == "+" else val - rhs
        i = j
    return val, i, None


def _eval_term(tokens: List[str], i: int) -> Tuple[Optional[Fraction], int, Optional[str]]:
    val, i, err = _eval_factor(tokens, i)
    if err:
        return None, i, err
    while i < len(tokens) and tokens[i] in "*/":
        op = tokens[i]
        rhs, j, err = _eval_factor(tokens, i + 1)
        if err:
            return None, j, err
        if op == "*":
            val = val * rhs
        else:
            if rhs == 0:
                return None, j, "division_by_zero"
            val = val / rhs
        i = j
    return val, i, None


def _eval_factor(tokens: List[str], i: int) -> Tuple[Optional[Fraction], int, Optional[str]]:
    if i >= len(tokens):
        return None, i, "truncated"
    neg = False
    if tokens[i] == "-":
        neg = True
        i += 1
        if i >= len(tokens):
            return None, i, "truncated"
    if re.fullmatch(_NUM_TOKEN, tokens[i] or ""):
        val = _to_fraction(tokens[i])
        if val is None:
            return None, i, "bad_number"
        return (-val if neg else val), i + 1, None
    return None, i, "not_a_number"


def _pretty(v: Fraction) -> str:
    if v.denominator == 1:
        return str(v.numerator)
    names = {2: "one half", 3: "one third", 4: "one quarter", 8: "one eighth"}
    if v.numerator == 1 and v.denominator in names:
        return names[v.denominator]
    return f"{v.numerator}/{v.denominator}"


def _dec(v: Fraction) -> str:
    f = float(v)
    return f"{f:g}"


def _format_expr(tokens: List[str], start: int, end: int) -> str:
    """Human-readable form of the expression that was parsed."""
    return " ".join(tokens[start:end])


def _try_parse_claim(run: str):
    """Parse '<expr> REL <expr>' from the token run. Returns
    (lhs_tokens, rel, rhs_tokens, lhs_val, rhs_val, err_kind) where err_kind
    is None on success, 'division_by_zero' for a /0 claim, else 'no_claim'."""
    tokens = _tokenize_run(run)
    rel_idx = None
    rel = None
    for idx, t in enumerate(tokens):
        if t in ("=", "!=", ">", "<"):
            if rel_idx is not None:
                return None, None, None, None, None, "no_claim"  # two relations -> ambiguous
            rel_idx, rel = idx, t
    if rel_idx is None or rel_idx == 0 or rel_idx == len(tokens) - 1:
        return None, None, None, None, None, "no_claim"
    lhs_tokens = tokens[:rel_idx]
    rhs_tokens = tokens[rel_idx + 1:]
    lhs, li, err_l = _eval_expr(lhs_tokens)
    rhs, _ri, err_r = _eval_expr(rhs_tokens)
    if "division_by_zero" in (err_l, err_r):
        return lhs_tokens, rel, rhs_tokens, None, None, "division_by_zero"
    if err_l or err_r or lhs is None or rhs is None:
        return None, None, None, None, None, "no_claim"
    if li != len(lhs_tokens):            # unparsed leftovers on LHS
        return None, None, None, None, None, "no_claim"
    return lhs_tokens, rel, rhs_tokens, lhs, rhs, None


def _build_verdict(orig_transcript: str, claim: str, lhs_tokens, rel, rhs_tokens,
                   lhs: Fraction, rhs: Fraction,
                   rounded_note: str = "") -> MathVerdict:
    lhs_txt = _format_expr(lhs_tokens, 0, len(lhs_tokens))
    rhs_txt = _format_expr(rhs_tokens, 0, len(rhs_tokens))
    rel_word = _REL_TEXT[rel]

    def is_single(toks):
        return len(toks) == 1

    if rel in ("=", "!="):
        kind_ok = "correct_arithmetic"
        topic = "fractions" if "/" in claim else "arithmetic"
        if rel == "=":
            equal = (lhs == rhs) or bool(rounded_note)
            if equal:
                note = f" (rounded to 2 decimals: {rounded_note})" if rounded_note else ""
                return MathVerdict(
                    status="correct", kind=kind_ok, topic=topic,
                    statement=f"{lhs_txt} {rel_word} {rhs_txt}",
                    explanation=f"Correct: {lhs_txt} = {lhs_txt and _pretty(lhs)}{note}".replace("= =", "= "),
                )
            correction = f"{lhs_txt} = {_pretty(lhs)}"
            return MathVerdict(
                status="error", kind="arithmetic_error", topic=topic,
                statement=f"{lhs_txt} {rel_word} {rhs_txt}",
                explanation=(f"Math error: teacher said \"{lhs_txt} is {rhs_txt}\" "
                             f"but {lhs_txt} actually equals {_pretty(lhs)} "
                             f"({lhs_txt} = {_pretty(lhs)}, not {rhs_txt})."),
                correction=correction,
            )
        # '!=' claim
        if lhs != rhs:
            return MathVerdict(
                status="correct", kind=kind_ok, topic=topic,
                statement=f"{lhs_txt} {rel_word} {rhs_txt}",
                explanation=f"Correct: {lhs_txt} = {_pretty(lhs)}, which is indeed not equal to {rhs_txt}.",
            )
        return MathVerdict(
            status="error", kind="arithmetic_error", topic=topic,
            statement=f"{lhs_txt} {rel_word} {rhs_txt}",
            explanation=(f"Math error: teacher said \"{lhs_txt} is not equal to {rhs_txt}\" "
                         f"but {lhs_txt} equals {_pretty(lhs)}, so it IS equal to {rhs_txt}."),
            correction=f"{lhs_txt} = {_pretty(lhs)} (it is equal to {rhs_txt})",
        )

    # comparisons > / <
    if rel == ">":
        holds = lhs > rhs
    else:
        holds = lhs < rhs
    topic = "fractions" if ("/" in lhs_txt or "/" in rhs_txt) else "arithmetic"
    if holds:
        return MathVerdict(
            status="correct", kind="correct_comparison", topic=topic,
            statement=f"{lhs_txt} {rel_word} {rhs_txt}",
            explanation=f"Correct: {_pretty(lhs)} ({_dec(lhs)}) is indeed {_REL_TEXT[rel]} {_pretty(rhs)} ({_dec(rhs)}).",
        )
    if lhs == rhs:
        actual = "equal to"
    else:
        actual = "greater than" if lhs > rhs else "less than"
    cmp_correction = f"{lhs_txt} {'>' if actual == 'greater than' else ('<' if actual == 'less than' else '=')} {rhs_txt}"
    return MathVerdict(
        status="error", kind="comparison_error", topic=topic,
        statement=f"{lhs_txt} {rel_word} {rhs_txt}",
        explanation=(f"Math error: teacher said \"{lhs_txt} is {_REL_TEXT[rel]} {rhs_txt}\" "
                     f"but {_pretty(lhs)} ({_dec(lhs)}) is actually {actual} "
                     f"{_pretty(rhs)} ({_dec(rhs)})."),
        correction=cmp_correction,
    )


def _check_fraction_of(text: str) -> Optional[MathVerdict]:
    """'half of 10 is 5' / 'two thirds of 90 is 60' / 'one quarter of 20 is 4'.

    By the time we get here, _fill_fraction_phrases + _compose_number_words
    turned 'two thirds of 90' into '2/3 of 90', and the relation stage turned
    'is' into '='. We match '<frac> of <num> = <ans>' directly."""
    m = re.search(rf"({ _NUM_TOKEN })\s+of\s+(-?\d+(?:\.\d+)?)\s*=\s*({ _NUM_TOKEN })", text)
    if not m:
        return None
    frac_tok, total_tok, ans_tok = m.group(1), m.group(2), m.group(3)
    frac = _to_fraction(frac_tok)
    total = _to_fraction(total_tok)
    ans = _to_fraction(ans_tok)
    if frac is None or total is None or ans is None:
        return None
    exact = frac * total
    frac_pretty = _pretty(frac)
    if exact == ans:
        return MathVerdict(
            status="correct", kind="correct_arithmetic", topic="fractions",
            statement=f"{frac_pretty} of {total_tok} is {ans_tok}",
            explanation=f"Correct: {frac_pretty} of {total_tok} = {_pretty(exact)}.",
        )
    return MathVerdict(
        status="error", kind="arithmetic_error", topic="fractions",
        statement=f"{frac_pretty} of {total_tok} is {ans_tok}",
        explanation=(f"Math error: teacher said \"{frac_pretty} of {total_tok} is {ans_tok}\" "
                     f"but {frac_pretty} of {total_tok} = {_pretty(exact)} ({_dec(exact)})."),
        correction=f"{frac_pretty} of {total_tok} = {_pretty(exact)}",
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check(transcript: str) -> Optional[MathVerdict]:
    """Check a transcript for a spoken math claim.

    Returns a MathVerdict (error or correct) only when a FULL claim
    '<expression> <relation> <expression>' is recognized; otherwise None.
    """
    if not transcript or not transcript.strip():
        return None
    text = _strip_punct(transcript)
    text = _FILLER_RE.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()

    for attempt_homophones in (False, True):
        work = text
        if attempt_homophones:
            # second pass only: map homophones in operand slots
            work = re.sub(r"(?<![a-z])(to|too|for|won|ate)(?=\s*(?:[+\-*/=!<>]|\d|-))",
                          lambda m: str(_HOMOPHONES[m.group(1)]), work)
            work = re.sub(r"(?<=[\d/])(?:\s+)(to|too|for|won|ate)(?![a-z])",
                          lambda m: f" {_HOMOPHONES[m.group(1)]}", work)

        stage = _fill_fraction_phrases(work)
        stage = _compose_number_words(stage)
        stage = _normalize_relations(stage)
        stage = _normalize_operators(stage)

        # 1. dedicated '<fraction> of N is M' claims
        verdict = _check_fraction_of(stage)
        if verdict:
            return verdict

        # 2. generic arithmetic/comparison claims
        run = _longest_token_run(stage)
        if run:
            lhs_tokens, rel, rhs_tokens, lhs, rhs, err = _try_parse_claim(run)
            if err == "division_by_zero":
                lhs_txt = _format_expr(lhs_tokens or [], 0, len(lhs_tokens or []))
                rhs_txt = _format_expr(rhs_tokens or [], 0, len(rhs_tokens or []))
                return MathVerdict(
                    status="error", kind="division_by_zero",
                    topic="arithmetic",
                    statement=f"{lhs_txt} = {rhs_txt}",
                    explanation=(f"Math error: teacher said \"{lhs_txt} is {rhs_txt}\" "
                                 "but we cannot divide a number by zero — division "
                                 "by 0 is not defined."),
                    correction="Division by zero is not possible — every number divided by 0 is undefined.",
                )
            if err is None and lhs is not None:
                rounded_note = ""
                if rel == "=" and lhs != rhs and "/" in run:
                    # accept 2-dp rounded answers for division claims
                    diff = abs(float(lhs) - float(rhs))
                    if diff <= 0.005:
                        rounded_note = f"{float(lhs):.2f}"
                return _build_verdict(transcript, run, lhs_tokens, rel,
                                      rhs_tokens, lhs, rhs, rounded_note)
    return None


def explain_no_event() -> str:
    return "No complete math claim recognized — nothing to verify."

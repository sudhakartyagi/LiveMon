from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from uuid import UUID

class PolicyCreate(BaseModel):
    name: str
    config: Dict[str, Any]

class ActionRequest(BaseModel):
    lesson_id: UUID
    action_type: str
    reason: str
    target_student_id: Optional[UUID] = None
    context: Dict[str, Any] = Field(default_factory=dict)

class DisputeRequest(BaseModel):
    flag_reason: str

class RateRequest(BaseModel):
    rating: str # "good", "bad"

class ApprovalDecision(BaseModel):
    """Teacher's yes/no on a proposed agent action."""
    note: Optional[str] = None

class AudioChunk(BaseModel):
    class_id: UUID
    lesson_id: UUID
    transcript: str
    speaker: str = "teacher"
    noise_db: int
    # Average Whisper segment log-prob from the pro listener. Optional for
    # backward compatibility; when present, low values gate tier-3 actions.
    confidence: Optional[float] = None

class CurriculumUpload(BaseModel):
    content: str

from fastapi import Header, HTTPException
from app.auth import verify_token

def get_principal(authorization: str = Header(...)) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    try:
        return verify_token(authorization[7:])
    except Exception:
        raise HTTPException(401, "Invalid token")

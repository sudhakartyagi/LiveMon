from contextlib import contextmanager
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from app.config import DATABASE_URL

engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_size=5)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

@contextmanager
def tenant_session(school_id: str) -> Session:
    session = SessionLocal()
    try:
        # FIX: PostgreSQL does not support bind parameters in SET LOCAL.
        # We use set_config() which accepts parameters. The 'true' argument
        # makes it transaction-local (like SET LOCAL).
        session.execute(
            text("SELECT set_config('app.current_tenant_id', :tid, true)"),
            {"tid": str(school_id)},
        )
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
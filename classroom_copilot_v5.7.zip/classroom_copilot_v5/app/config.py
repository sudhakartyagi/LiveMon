import os

ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALG = "HS256"

if ENVIRONMENT == "production" and not JWT_SECRET:
    raise RuntimeError("JWT_SECRET must be set in production")

JWT_SECRET = JWT_SECRET or "dev-only-secret-do-not-use-in-prod"

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg://app_user:app_pass@localhost:5432/copilot",
)

import streamlit as st
import httpx
import uuid

API_URL = "http://localhost:8000"
st.set_page_config(page_title="Classroom Agent v5.7", layout="wide")
st.title("🤖 Classroom Agent v5.7 — Permission-First Co-pilot")

st.sidebar.header("Authentication")
token = st.sidebar.text_input("Paste JWT Token here", type="password")
if not token: st.stop()
HEADERS = {"Authorization": f"Bearer {token}"}

tab1, tab_appr, tab2, tab3 = st.tabs(["Teacher View", "✅ Approvals", "Principal Digest", "Curriculum Upload"])

with tab1:
    st.header("Teacher Live Dashboard")
    class_id = st.text_input("Class ID", value="e7061104-7c79-46b6-84c1-bad640d12761")
    lesson_id = st.text_input("Lesson ID", value="b89639f4-0fef-46e4-8740-5f501e63d62d")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("🚨 Pause Agent (Kill Switch)"):
            httpx.post(f"{API_URL}/agent/pause/{class_id}", headers=HEADERS)
            st.success("Paused")
    with col2:
        if st.button("▶️ Resume Agent"):
            httpx.post(f"{API_URL}/agent/resume/{class_id}", headers=HEADERS)
            st.success("Resumed")

    st.subheader("Simulate Live Audio")
    transcript = st.text_area("Teacher Transcript", value="2 plus 2 is 3")
    noise_db = st.slider("Noise Level (dB)", 0, 100, 50)
    confidence = st.slider("ASR confidence (avg log-prob)", -2.0, 0.0, -0.2, 0.05)

    if st.button("🎤 Send Audio Chunk"):
        r = httpx.post(f"{API_URL}/audio/ingest", headers=HEADERS, json={
            "class_id": class_id, "lesson_id": lesson_id,
            "transcript": transcript, "speaker": "teacher",
            "noise_db": noise_db, "confidence": confidence
        })
        st.json(r.json())

    st.subheader("Live Timeline & Feedback")
    if st.button("Refresh Timeline"):
        r = httpx.get(f"{API_URL}/teacher/dashboard/{lesson_id}", headers=HEADERS)
        if r.status_code == 200:
            actions = r.json()
            for a in actions:
                with st.expander(f"[{a['time']}] {a['action']} (Tier {a['tier']}) — {a['status']}"):
                    st.write(f"**Reason:** {a['reason']}")
                    if a.get("proposal"):
                        st.write(f"**Proposal:** {a['proposal']}")
                    st.write(f"**Status:** {a['status']}")

                    # Feedback buttons
                    c1, c2, c3 = st.columns(3)
                    if c1.button("✅ Accept", key=f"acc_{a['id']}"):
                        httpx.post(f"{API_URL}/actions/{a['id']}/rate", headers=HEADERS, json={"rating": "good"})
                        st.success("Rated Good!")
                    if c2.button("❌ Reject", key=f"rej_{a['id']}"):
                        httpx.post(f"{API_URL}/actions/{a['id']}/rate", headers=HEADERS, json={"rating": "bad"})
                        st.warning("Rated Bad!")
                    if c3.button("🚩 Flag", key=f"flg_{a['id']}"):
                        httpx.post(f"{API_URL}/actions/{a['id']}/flag", headers=HEADERS, json={"flag_reason": "Teacher disagreed"})
                        st.error("Flagged to Principal")

with tab_appr:
    st.header("✅ Pending Approvals (Propose → Permission → Act → Log)")
    st.caption("The agent never speaks to the class until you allow it here. "
               "Whole-class scripted reminders are pre-approved; corrections and "
               "suggestions always ask first.")
    lesson_for_approval = st.text_input("Lesson ID for approvals", value=lesson_id, key="appr_lesson")
    if st.button("🔄 Refresh pending list"):
        st.rerun()
    r = httpx.get(f"{API_URL}/actions/pending", headers=HEADERS, params={"lesson_id": lesson_for_approval})
    if r.status_code == 200:
        pending = r.json()
        if not pending:
            st.info("No pending proposals — the agent is in observe mode or everything was already decided.")
        for p in pending:
            with st.container(border=True):
                st.write(f"**[{p['time']}] Tier {p['tier']} · {p['action_type']}**")
                st.write(f"**Detected:** {p['reason']}")
                if p.get("proposal"):
                    st.write(f"**Wants to say/show:** {p['proposal']}")
                c1, c2 = st.columns(2)
                if c1.button("✅ Allow", key=f"appr_yes_{p['id']}"):
                    rr = httpx.post(f"{API_URL}/actions/{p['id']}/approve", headers=HEADERS, json={})
                    if rr.status_code == 200:
                        st.success(f"Approved — the agent may now say: {rr.json().get('spoken_text')}")
                    else:
                        st.error(rr.json().get("detail", "Failed"))
                if c2.button("❌ Skip", key=f"appr_no_{p['id']}"):
                    rr = httpx.post(f"{API_URL}/actions/{p['id']}/deny", headers=HEADERS, json={})
                    if rr.status_code == 200:
                        st.warning("Skipped — proposal logged, nothing was spoken.")
                    else:
                        st.error(rr.json().get("detail", "Failed"))
    else:
        st.error(f"Could not load pending list (HTTP {r.status_code})")

with tab2:
    st.header("Principal After-Class Digest")
    if st.button("Load Today's Digest"):
        r = httpx.get(f"{API_URL}/principal/digest", headers=HEADERS)
        if r.status_code == 200:
            data = r.json()
            st.subheader("Action Items (Tier 4)")
            st.table(data.get("action_items", []))
            st.subheader("Disputes")
            st.table(data.get("disputes", []))
            st.subheader("Discipline Logs")
            st.table(data.get("discipline_flags", []))

with tab3:
    st.header("Curriculum Grounding (RAG)")
    curriculum_text = st.text_area("Paste NCERT Chapter Text", height=200)
    if st.button("Upload to Vector DB"):
        r = httpx.post(f"{API_URL}/curriculum/upload", headers=HEADERS, json={"content": curriculum_text})
        if r.status_code == 200: st.success(r.json())

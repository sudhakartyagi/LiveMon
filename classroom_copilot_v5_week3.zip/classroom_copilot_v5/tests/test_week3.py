import uuid
from sqlalchemy import text
from app.main import app
from app.db import tenant_session

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_teacher_dashboard(client, two_schools):
    # Setup: Create a lesson and an action
    lesson_id = uuid.uuid4()
    with tenant_session(two_schools["school_a"]) as db:
        db.execute(text("INSERT INTO lessons (id, school_id, class_id) VALUES (:id, :sid, :cid)"), 
                   {"id": lesson_id, "sid": two_schools["school_a"], "cid": uuid.uuid4()})
    
    client.post("/actions", headers=auth(two_schools["token_a"]), json={
        "lesson_id": str(lesson_id),
        "action_type": "recap",
        "reason": "Pacing check",
        "context": {}
    })

    # Teacher fetches dashboard
    r = client.get(f"/teacher/dashboard/{lesson_id}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 200
    assert len(r.json()) == 1
    assert r.json()[0]["action"] == "recap"

def test_principal_digest(client, two_schools, monkeypatch):
    # Mock the token to have role="principal"
    monkeypatch.setattr("app.deps.get_principal", lambda authorization: {
        "sub": str(uuid.uuid4()),
        "school_id": str(two_schools["school_a"]),
        "role": "principal"
    })

    # Create a Tier 4 action (teacher absent)
    client.post("/actions", headers=auth("fake"), json={
        "lesson_id": str(uuid.uuid4()),
        "action_type": "teacher_absent",
        "reason": "Teacher absent > 3 min",
        "context": {"teacher_absent_minutes": 5}
    })

    r = client.get("/principal/digest", headers=auth("fake"))
    assert r.status_code == 200
    assert len(r.json()["action_items"]) >= 1

def test_principal_cannot_see_other_school_digest(client, two_schools, monkeypatch):
    monkeypatch.setattr("app.deps.get_principal", lambda authorization: {
        "sub": str(uuid.uuid4()),
        "school_id": str(two_schools["school_b"]),
        "role": "principal"
    })

    # School B principal tries to view digest. Should be empty.
    r = client.get("/principal/digest", headers=auth("fake"))
    assert r.status_code == 200
    assert len(r.json()["action_items"]) == 0
    assert len(r.json()["disputes"]) == 0

# Classroom Agent v5.0 — Week 3

Week 3 adds the Teacher Dashboard, Principal Digest, and Action Resolution.

## Run
1. `python -m pytest -v`

## New Features
- **Teacher Dashboard**: `/teacher/dashboard/{lesson_id}` shows the teacher a timeline of what the agent did.
- **Principal Digest**: `/principal/digest` aggregates Tier 4 alerts, Disputes, and Discipline flags for a specific date.
- **Resolution**: `/principal/resolve/{action_id}` allows the principal to close out Action Items.
- **Strict Role Isolation**: Teachers cannot access the Principal Digest, and Principals cannot see other schools' data.

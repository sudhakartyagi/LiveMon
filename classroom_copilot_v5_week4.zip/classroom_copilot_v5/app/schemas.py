from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from uuid import UUID

class PolicyCreate(BaseModel):
    name: str
    config: Dict[str, Any]

class ActionRequest(BaseModel):
    lesson_id: UUID
    action_type: str
    reason: str
    context: Dict[str, Any] = Field(default_factory=dict)

class DisputeRequest(BaseModel):
    flag_reason: str

class AudioChunk(BaseModel):
    class_id: UUID
    transcript: str
    speaker: str
    noise_db: int

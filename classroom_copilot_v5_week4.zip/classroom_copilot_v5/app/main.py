import uuid
from datetime import datetime, timedelta
from fastapi import FastAPI, Depends, HTTPException
from app.db import tenant_session
from app.deps import get_principal
from app.models import Student, AgentAction, Policy, AuditLog, Dispute, Lesson, ClassState
from app.schemas import PolicyCreate, ActionRequest, DisputeRequest, AudioChunk
from app.engine import PolicyEngine
from app.audio import AudioProcessor

app = FastAPI(title="Classroom Agent v5.0 (Week 4)")

@app.get("/health")
def health():
    return {"status": "ok", "version": "5.0.0-week4"}

@app.post("/audio/ingest")
def ingest_audio(chunk: AudioChunk, principal=Depends(get_principal)):
    """
    Receives raw audio chunks (simulated via text/noise).
    Extracts features, triggers actions, but DOES NOT save the raw chunk.
    """
    with tenant_session(principal["school_id"]) as db:
        # 1. Check Kill Switch
        state = db.query(ClassState).filter(ClassState.class_id == chunk.class_id).first()
        if state and state.is_paused:
            return {"status": "ignored", "reason": "Agent is paused for this class"}

        # 2. Process Audio
        result = AudioProcessor.process_chunk(chunk.dict())
        
        if result:
            # 3. Log Action (Tier 0-2)
            action = AgentAction(
                school_id=uuid.UUID(principal["school_id"]),
                lesson_id=uuid.uuid4(), # Mocking lesson_id for now
                action_type=result["action_type"],
                tier=result["tier"],
                reason=result["reason"],
                status="logged" if result["tier"] == 0 else "executed"
            )
            db.add(action)
            db.flush()
            
            return {
                "status": "action_triggered",
                "action_id": str(action.id),
                "tier": result["tier"],
                "reason": result["reason"]
            }
            
        return {"status": "processed", "action": None}

@app.post("/agent/pause/{class_id}")
def pause_agent(class_id: uuid.UUID, principal=Depends(get_principal)):
    """Kill Switch: Principal or Teacher pauses the agent for a class."""
    with tenant_session(principal["school_id"]) as db:
        state = db.query(ClassState).filter(ClassState.class_id == class_id).first()
        if not state:
            state = ClassState(
                school_id=uuid.UUID(principal["school_id"]),
                class_id=class_id,
                is_paused=True,
                paused_at=datetime.utcnow()
            )
            db.add(state)
        else:
            state.is_paused = True
            state.paused_at = datetime.utcnow()
            
        return {"status": "paused", "class_id": str(class_id)}

@app.post("/agent/resume/{class_id}")
def resume_agent(class_id: uuid.UUID, principal=Depends(get_principal)):
    """Resume the agent."""
    with tenant_session(principal["school_id"]) as db:
        state = db.query(ClassState).filter(ClassState.class_id == class_id).first()
        if state:
            state.is_paused = False
            state.paused_at = None
        return {"status": "resumed", "class_id": str(class_id)}

@app.post("/policies", status_code=201)
def create_policy(policy: PolicyCreate, principal=Depends(get_principal)):
    if principal.get("role") not in ["admin", "principal"]:
        raise HTTPException(403, "Only principal/admin can set policies")
    with tenant_session(principal["school_id"]) as db:
        new_policy = Policy(
            school_id=uuid.UUID(principal["school_id"]),
            name=policy.name,
            config=policy.config
        )
        db.add(new_policy)
        db.flush()
        return {"id": str(new_policy.id)}

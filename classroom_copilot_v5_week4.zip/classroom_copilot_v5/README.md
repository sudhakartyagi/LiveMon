# Classroom Agent v5.0 — Week 4

Week 4 adds the Audio Pipeline, Live Actions (Tier 0-2), and the Kill Switch.

## Run
1. `python -m alembic upgrade head`
2. `python -m pytest -v`

## New Features
- **Audio Ingestion**: `/audio/ingest` receives transcribed text and noise levels.
- **Feature Extraction**: Triggers `scripted_reminder` if noise > 75dB.
- **Zero Storage**: Raw transcripts are processed in memory and discarded. Only the `AgentAction` is logged.
- **Kill Switch**: `/agent/pause` and `/agent/resume` allow the principal to instantly disable the agent for a specific class.

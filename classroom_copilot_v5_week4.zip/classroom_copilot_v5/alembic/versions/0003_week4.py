"""Week 4: Audio State & Kill Switch"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0003"
down_revision = "0002"

def upgrade():
    # 1. Track Agent State (Pause/Resume) per Class
    op.create_table(
        "class_states",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("school_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("schools.id"), nullable=False),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("classes.id"), nullable=False),
        sa.Column("is_paused", sa.Boolean, server_default="false"),
        sa.Column("paused_at", sa.DateTime, nullable=True),
    )
    
    op.execute("ALTER TABLE class_states ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE class_states FORCE ROW LEVEL SECURITY")
    op.execute("""
        CREATE POLICY tenant_isolation ON class_states
        USING (school_id = current_setting('app.current_tenant_id', true)::uuid)
        WITH CHECK (school_id = current_setting('app.current_tenant_id', true)::uuid)
    """)
    op.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON class_states TO app_user")

def downgrade():
    op.execute("DROP TABLE IF EXISTS class_states CASCADE")

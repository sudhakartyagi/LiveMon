import uuid
from sqlalchemy import text
from app.main import app
from app.db import tenant_session

def auth(token):
    return {"Authorization": f"Bearer {token}"}

def test_audio_ingest_noise_trigger(client, two_schools):
    # Send a noisy chunk
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(uuid.uuid4()),
        "transcript": "Let's move to page 42",
        "speaker": "teacher",
        "noise_db": 80
    })
    assert r.status_code == 200
    assert r.json()["status"] == "action_triggered"
    assert r.json()["tier"] == 2

def test_audio_ingest_clean_audio(client, two_schools):
    # Send a clean chunk
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(uuid.uuid4()),
        "transcript": "Let's move to page 42",
        "speaker": "teacher",
        "noise_db": 40
    })
    assert r.status_code == 200
    assert r.json()["status"] == "processed"

def test_kill_switch(client, two_schools):
    class_id = uuid.uuid4()
    
    # 1. Pause agent
    r = client.post(f"/agent/pause/{class_id}", headers=auth(two_schools["token_a"]))
    assert r.status_code == 200

    # 2. Try to ingest audio (should be ignored)
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(class_id),
        "transcript": "Teacher is talking",
        "speaker": "teacher",
        "noise_db": 90
    })
    assert r.json()["status"] == "ignored"

    # 3. Resume agent
    client.post(f"/agent/resume/{class_id}", headers=auth(two_schools["token_a"]))
    
    # 4. Try again (should trigger)
    r = client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(class_id),
        "transcript": "Teacher is talking",
        "speaker": "teacher",
        "noise_db": 90
    })
    assert r.json()["status"] == "action_triggered"

def test_no_raw_audio_stored(client, two_schools):
    """Proof that we extract features but do not store the raw transcript."""
    class_id = uuid.uuid4()
    
    client.post("/audio/ingest", headers=auth(two_schools["token_a"]), json={
        "class_id": str(class_id),
        "transcript": "1/2 is bigger than 3/4", # Should trigger misconception log
        "speaker": "teacher",
        "noise_db": 40
    })

    with tenant_session(two_schools["school_a"]) as db:
        # Check that the action was logged
        actions = db.execute(text("SELECT action_type FROM agent_actions")).fetchall()
        assert len(actions) >= 1
        
        # PROVE: There is no table or column storing the raw transcript
        # The database only knows the *type* of action, not the words spoken.
        # (This is a conceptual test; in a real DB, we'd assert `transcript` doesn't exist)
        pass

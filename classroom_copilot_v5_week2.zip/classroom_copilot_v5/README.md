# Classroom Agent v5.0 — Week 2

Week 2 adds the Agent Core, Policy Engine, Dispute Engine, Audit Log, and Concurrency Testing.

## Run
1. `python -m alembic upgrade head`
2. `python -m pytest -v`

## New Features
- **Policy Engine** (`app/engine.py`): Routes actions to Tier 0-4 based on school policy and hard safety limits (e.g., teacher absent > 3 mins).
- **Audit Log**: Records all actions and flags cross-tenant attempts.
- **Dispute Engine**: Endpoint `/actions/{id}/flag` allows teachers to dispute an action, which auto-resolves in-moment.
- **Concurrency Test**: Proves RLS holds when multiple schools query the DB simultaneously.

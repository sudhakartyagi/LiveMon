import uuid
from fastapi import FastAPI, Depends, HTTPException, status
from app.db import tenant_session
from app.deps import get_principal
from app.models import Student, AgentAction, Policy, AuditLog, Dispute
from app.schemas import PolicyCreate, ActionRequest, DisputeRequest
from app.engine import PolicyEngine

app = FastAPI(title="Classroom Agent v5.0 (Week 2)")

@app.get("/health")
def health():
    return {"status": "ok", "version": "5.0.0-week2"}

@app.get("/students/{student_id}")
def get_student(student_id: uuid.UUID, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        student = db.get(Student, student_id)
        if student is None:
            raise HTTPException(404, "Not found")
        return {"id": str(student.id), "pseudonym": student.pseudonym}

@app.post("/policies", status_code=201)
def create_policy(policy: PolicyCreate, principal=Depends(get_principal)):
    if principal.get("role") != "admin" and principal.get("role") != "principal":
        raise HTTPException(403, "Only principal/admin can set policies")
    with tenant_session(principal["school_id"]) as db:
        new_policy = Policy(
            school_id=uuid.UUID(principal["school_id"]),
            name=policy.name,
            config=policy.config
        )
        db.add(new_policy)
        db.flush()
        return {"id": str(new_policy.id)}

@app.post("/actions", status_code=201)
def trigger_action(req: ActionRequest, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        # Fetch active policy (fallback to default if none)
        policy = db.query(Policy).order_by(Policy.created_at.desc()).first()
        config = policy.config if policy else {}

        # Route the action
        tier = PolicyEngine.route_action(req.action_type, req.context, config)

        action = AgentAction(
            school_id=uuid.UUID(principal["school_id"]),
            lesson_id=req.lesson_id,
            action_type=req.action_type,
            tier=tier,
            reason=req.reason,
            principal_notified=(tier == 4)
        )
        db.add(action)
        db.flush()

        # Log to audit
        audit = AuditLog(
            school_id=uuid.UUID(principal["school_id"]),
            actor_id=uuid.UUID(principal["sub"]),
            action="trigger_action",
            resource=f"action:{action.id}",
            is_cross_tenant_attempt=False
        )
        db.add(audit)

        return {
            "id": str(action.id),
            "tier": tier,
            "requires_principal": (tier == 4)
        }

@app.post("/actions/{action_id}/flag", status_code=201)
def flag_action(action_id: uuid.UUID, req: DisputeRequest, principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        action = db.get(AgentAction, action_id)
        if not action:
            raise HTTPException(404, "Action not found")

        dispute = Dispute(
            school_id=uuid.UUID(principal["school_id"]),
            agent_action_id=action.id,
            teacher_id=uuid.UUID(principal["sub"]),
            flag_reason=req.flag_reason,
            resolution="agent_right" if action.tier <= 2 else "agent_wrong" # Mock resolution logic
        )
        db.add(dispute)
        
        # Update action status
        action.status = "flagged"
        
        return {"dispute_id": str(dispute.id), "resolution": dispute.resolution}

@app.get("/audit")
def get_audit(principal=Depends(get_principal)):
    with tenant_session(principal["school_id"]) as db:
        logs = db.query(AuditLog).all()
        return [{"action": l.action, "resource": l.resource} for l in logs]

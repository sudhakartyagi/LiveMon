from enum import IntEnum
from typing import Dict, Any
from app.models import Policy

class Tier(IntEnum):
    OBSERVE = 0     # Log only
    SILENT = 1      # Notify teacher silently
    ACT = 2         # Act + notify teacher
    CORRECT = 3     # Interject + notify principal (Digest)
    ESCALATE = 4    # Live push to principal

class PolicyEngine:
    @staticmethod
    def route_action(action_type: str, context: Dict[str, Any], policy_config: dict) -> int:
        """
        Decides the tier based on the action type, context, and school policy.
        Default fallback rules apply if policy does not specify.
        """
        # 1. Hard safety rules (always override policy)
        if context.get("teacher_absent_minutes", 0) > 3:
            return Tier.ESCALATE
        
        if context.get("safety_event"):
            return Tier.ESCALATE

        # 2. Custom School Policy
        rules = policy_config.get("rules", {})
        if action_type in rules:
            return int(rules[action_type])

        # 3. Default Agent Behavior
        defaults = {
            "timer": Tier.ACT,
            "recap": Tier.ACT,
            "common_mistake": Tier.ACT,
            "language_nudge": Tier.ACT,
            "factual_correction": Tier.CORRECT,
            "praise_naming": Tier.CORRECT,
            "individual_hint": Tier.SILENT,
            "discipline_naming": Tier.OBSERVE, # Default digest-only
        }
        return defaults.get(action_type, Tier.OBSERVE)
